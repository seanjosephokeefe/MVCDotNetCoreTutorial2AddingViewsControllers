﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVCTutorial2.Controllers
{
    public class InfoFormController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ShowResults(String first, String last, String gender, String month)
        {
            ViewData["first"] = first;
            ViewData["last"] = last;
            ViewData["gender"] = gender;
            ViewData["month"] = month;
            return View("Results");
        }
    }
}